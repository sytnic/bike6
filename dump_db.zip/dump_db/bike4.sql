-- Adminer 4.3.1 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `admins`;
CREATE TABLE `admins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `hashed_password` varchar(60) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `admins` (`id`, `username`, `hashed_password`) VALUES
(2,	'kskoglund',	'$2y$10$N2M3MDRmMDAxYjM5MjI4NO8si6dsnBN11c0wd7hi3ZffaguBrty32');

DROP TABLE IF EXISTS `pages`;
CREATE TABLE `pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int(11) unsigned NOT NULL,
  `categ2_id` smallint(5) unsigned DEFAULT NULL,
  `category` varchar(30) DEFAULT NULL,
  `title` varchar(100) NOT NULL,
  `position` int(3) DEFAULT NULL,
  `visible` tinyint(1) DEFAULT NULL,
  `date_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `description` tinytext NOT NULL,
  `content` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `date_created` (`date_created`),
  KEY `fk_pages_categories_idx` (`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `pages` (`id`, `category_id`, `categ2_id`, `category`, `title`, `position`, `visible`, `date_updated`, `date_created`, `description`, `content`) VALUES
(1,	2,	0,	'MVC. Front Controller',	'MVC-основы(до БД)',	1,	1,	'2020-05-17 16:46:51',	'2020-05-17 16:15:31',	'Описание. MVC. Front Controller. MVC-основы (до БД).',	'<p>Контент. MVC. Front Controller. MVC-основы (до БД).</p>'),
(2,	2,	0,	'0',	'Не стойки',	2,	1,	'2020-05-17 16:22:50',	'2017-12-13 08:05:13',	'Никаких стоек',	'<p>Не будет тут никакх стоек.</p>'),
(3,	1,	0,	'Html-tags',	'HTML теги',	3,	1,	'2020-05-18 14:55:24',	'2017-12-13 08:06:44',	'HTML теги страниц.',	'<p>HTML теги веб-страниц для отображения на сайтах.</p>\r\n<p>Возможны различные вариации тегов.</p>\r\n<p>Large widgets is here. Large widgets is here.</p>'),
(4,	2,	0,	'0',	'Колодки',	3,	1,	'2020-05-18 14:55:31',	'2017-12-13 10:42:52',	'Колодки тормозные. \r\nРассматриваются безасбестовые колодки.',	'<p>Тормозные колодки безасбестовые. \r\nЛучшее качество и применение в условиях торможения на снегу.</p>'),
(5,	1,	0,	'0',	'Фильтра',	6,	1,	'2020-05-18 14:55:37',	'2017-12-13 10:44:12',	'Фильтра воздушные и масляные.',	'<p>Фильтра воздушные и масляные,\r\n выполненные из высококачественной бумаги.&nbsp;</p>'),
(6,	2,	0,	'Php-Procedure',	'PHP функции',	6,	1,	'2020-05-18 14:55:43',	'2017-12-13 12:08:50',	'Экранирование',	'<p>Php функция экранирования mysli_real_escape_string.</p>'),
(7,	3,	0,	'0',	'Alert',	9,	1,	'2020-05-18 14:55:49',	'2017-12-13 12:08:50',	'Экранирование',	'<div class=\"alert alert-info\" role=\"alert\">\r\n<p>With HTML you can create your own Website.</p>\r\n<p>This tutorial teaches you everything about HTML.</p>\r\n<p>HTML is easy to learn - You will enjoy it.</p>\r\n</div>\r\n'),
(8,	1,	NULL,	NULL,	'вапва',	4,	1,	'2020-05-18 16:02:09',	'2020-05-18 16:01:40',	'вапвап',	'вапвап'),
(9,	1,	NULL,	NULL,	'Мое название',	5,	1,	'2020-05-18 16:10:47',	'2020-05-18 16:03:19',	'Мое описание',	'Мой контент.\r\nПотом новая строка.\r\nИ еще много строк.\r\nИ еще много строк. Потом новая строка. Потом новая строка. Потом новая строка. Потом новая строка.'),
(10,	2,	NULL,	NULL,	'Стопервое название',	6,	1,	'2020-05-18 16:11:08',	'2020-05-18 16:06:01',	'стопервое описание',	'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam eget sapien sapien. Curabitur in metus urna. In hac habitasse platea dictumst. Phasellus eu sem sapien, sed vestibulum velit. Nam purus nibh, lacinia non faucibus et, pharetra in dolor. Sed iaculis posuere diam ut cursus. Morbi commodo sodales nisi id sodales. Proin consectetur, nisi id commodo imperdiet, metus nunc consequat lectus, id bibendum diam velit et dui. \r\nProin massa magna, vulputate nec bibendum nec, posuere nec lacus. Aliquam mi erat, aliquam vel luctus eu, pharetra quis elit. Nulla euismod ultrices massa, et feugiat ipsum consequat eu.'),
(11,	2,	NULL,	NULL,	'Моя новое название',	7,	1,	'2020-05-18 16:11:25',	'2020-05-18 16:09:37',	'Мое новое описание',	'<p>Lorem ipsum dolor sit amet, <strong>consectetur adipiscing elit</strong>. Aliquam eget sapien sapien. Curabitur in metus urna. In hac habitasse platea dictumst. Phasellus eu sem sapien, sed vestibulum velit. Nam purus nibh, lacinia non faucibus et, pharetra in dolor. Sed iaculis posuere diam ut cursus. <em>Morbi commodo sodales nisi id sodales. Proin consectetur, nisi id commodo imperdiet, metus nunc consequat lectus, id bibendum diam velit et dui.</em> Proin massa magna, vulputate nec bibendum nec, posuere nec lacus. <small>Aliquam mi erat, aliquam vel luctus eu, pharetra quis elit. Nulla euismod ultrices massa, et feugiat ipsum consequat eu.</small>        \r\n</p>\r\n'),
(12,	1,	NULL,	NULL,	'sdfdsg',	9,	1,	'2020-05-18 16:16:47',	'2020-05-18 16:16:19',	'sdgdsfgds',	'<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam eget sapien sapien. Curabitur in metus urna. In hac habitasse platea dictumst. Phasellus eu sem sapien, sed vestibulum velit. Nam purus nibh, lacinia non faucibus et, pharetra in dolor. Sed iaculis posuere diam ut cursus. Morbi commodo sodales nisi id sodales. Proin consectetur, nisi id commodo imperdiet, metus nunc consequat lectus, id bibendum diam velit et dui. </p>\r\n<img src=\"/images/240x400-1.png\" style=\"padding:15px 0px; \" >\r\n<p>\r\nProin massa magna, vulputate nec bibendum nec, posuere nec lacus. Aliquam mi erat, aliquam vel luctus eu, pharetra quis elit. Nulla euismod ultrices massa, et feugiat ipsum consequat eu.\r\n</p>\r\n\r\n'),
(13,	1,	NULL,	NULL,	'ываыва',	NULL,	NULL,	'2020-05-18 17:45:08',	'2020-05-18 17:45:08',	'ываывавы',	'<h3>ывавыа</h3>\r\n<p>ываывавыааааааааааааааа&nbsp; аааааааааааа</p>'),
(14,	1,	NULL,	NULL,	'апрпар',	NULL,	NULL,	'2020-05-18 17:46:43',	'2020-05-18 17:46:43',	'апрпарпа',	'Спасибо, что вы заинтересовались контентом нашего сайта. К сожалению, срок действия вашей учетной записи истек. Пожалуйста, обновите вашу учетную запись, чтобы получить доступ к контенту сайта.'),
(15,	1,	NULL,	NULL,	'ааа',	NULL,	NULL,	'2020-05-18 17:50:12',	'2020-05-18 17:50:12',	'ааа',	'<p>Lorem ipsum dolor sit amet, <strong>consectetur adipiscing elit</strong>. Aliquam eget sapien sapien. Curabitur in metus urna. In hac habitasse platea dictumst. Phasellus eu sem sapien, sed vestibulum velit. Nam purus nibh, lacinia non faucibus et, pharetra in dolor. Sed iaculis posuere diam ut cursus. <em>Morbi commodo sodales nisi id sodales. Proin consectetur, nisi id commodo imperdiet, metus nunc consequat lectus, id bibendum diam velit et dui.</em> Proin massa magna, vulputate nec bibendum nec, posuere nec lacus. <small>Aliquam mi erat, aliquam vel luctus eu, pharetra quis elit. Nulla euismod ultrices massa, et feugiat ipsum consequat eu.</small></p>'),
(16,	1,	NULL,	NULL,	'фывфывфы',	NULL,	NULL,	'2020-05-18 17:53:06',	'2020-05-18 17:53:06',	'фывфыв',	'<p>Новый контент хочу добавить.</p>'),
(17,	2,	NULL,	NULL,	'ккк',	NULL,	NULL,	'2020-05-18 18:17:53',	'2020-05-18 18:17:53',	'ккк',	'<p>Сколько много слов можно написать. Это новый эмси.</p>\r\n<p>Пятый уже.</p>'),
(18,	2,	NULL,	NULL,	'ккк',	NULL,	NULL,	'2020-05-18 18:22:29',	'2020-05-18 18:22:29',	'ккк',	'<p>Сколько много слов можно написать. Это новый эмси.</p>\r\n<p>Пятый уже.</p>'),
(19,	1,	NULL,	NULL,	'ghjghjhg',	NULL,	1,	'2020-05-18 18:38:35',	'2020-05-18 18:38:04',	'hgjghjhg',	'<p>Lorem ipsum dolor sit amet <strong>consectetur adipiscing elit</strong>.</p>\r\n<p>Aliquam eget sapien sapien. Curabitur in metus urna. In hac habitasse platea dictumst. Phasellus eu sem sapien, sed vestibulum velit. Nam purus nibh, lacinia non faucibus et, pharetra in dolor. Sed iaculis posuere diam ut cursus.</p>\r\n<p><em>Morbi commodo sodales nisi id sodales. Proin consectetur, nisi id commodo imperdiet, metus nunc consequat lectus, id bibendum diam velit et dui.</em></p>\r\n<p>Proin massa magna, vulputate nec bibendum nec, posuere nec lacus.</p>\r\n<p><small>Aliquam mi erat, aliquam vel luctus eu, pharetra quis elit. Nulla euismod ultrices massa, et feugiat ipsum consequat eu.</small></p>'),
(20,	2,	NULL,	NULL,	'вапвап',	NULL,	1,	'2020-09-04 16:16:12',	'2020-05-18 18:42:42',	'вапва',	'Что добавишь, то и добавится.\r\n\r\n<h5> Bkb нет?</h5>'),
(21,	1,	NULL,	NULL,	'111111',	NULL,	1,	'2020-09-04 16:17:28',	'2020-05-18 20:19:16',	'1111111111',	'<p>Проверка офрграфии.</p>\r\n<p> всё равно проверяет.</p>\r\n<p>Агагаг</p>\r\n<p>Lorem ipsum dolor sit amet,&nbsp;<strong>consectetur adipiscing elit</strong>. Aliquam eget sapien sapien. Curabitur in metus urna. In hac habitasse platea dictumst. Phasellus eu sem sapien, sed vestibulum velit. Nam purus nibh, lacinia non faucibus et, pharetra in dolor. Sed iaculis posuere diam ut cursus.&nbsp;<em>Morbi commodo sodales nisi id sodales. Proin consectetur, nisi id commodo imperdiet, metus nunc consequat lectus, id bibendum diam velit et dui.</em>&nbsp;Proin massa magna, vulputate nec bibendum nec, posuere nec lacus.&nbsp;<small>Aliquam mi erat, aliquam vel luctus eu, pharetra quis elit. Nulla euismod ultrices massa, et feugiat ipsum consequat eu.</small></p>\r\n<h2>Заголовок</h2>\r\n<p><img src=\"../images/240x400-1.png\" alt=\"\" width=\"156\" height=\"260\" /></p>');

DROP TABLE IF EXISTS `txtdb`;
CREATE TABLE `txtdb` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `categ1_id` smallint(5) unsigned NOT NULL,
  `categ2_id` smallint(5) unsigned DEFAULT NULL,
  `categ3_id` smallint(5) unsigned DEFAULT NULL,
  `category` varchar(30) NOT NULL,
  `title` varchar(100) NOT NULL,
  `position` int(3) NOT NULL,
  `visible` tinyint(1) NOT NULL,
  `date_updated` timestamp NOT NULL ON UPDATE CURRENT_TIMESTAMP,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `description` tinytext NOT NULL,
  `content` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `date_created` (`date_created`),
  KEY `fk_pages_categories_idx` (`categ1_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `txtdb` (`id`, `categ1_id`, `categ2_id`, `categ3_id`, `category`, `title`, `position`, `visible`, `date_updated`, `date_created`, `description`, `content`) VALUES
(1,	2,	0,	0,	'MVC. Front Controller',	'MVC-основы(до БД)',	1,	1,	'2020-05-17 16:46:51',	'2020-05-17 16:15:31',	'Описание. MVC. Front Controller. MVC-основы (до БД).',	'<p>Контент. MVC. Front Controller. MVC-основы (до БД).</p>'),
(2,	2,	0,	0,	'0',	'Не стойки',	2,	1,	'2020-05-17 16:22:50',	'2017-12-13 08:05:13',	'Никаких стоек',	'<p>Не будет тут никакх стоек.</p>'),
(3,	1,	0,	0,	'Html-tags',	'HTML теги',	3,	1,	'0000-00-00 00:00:00',	'2017-12-13 08:06:44',	'HTML теги страниц.',	'<p>HTML теги веб-страниц для отображения на сайтах.</p>\r\n<p>Возможны различные вариации тегов.</p>\r\n<p>Large widgets is here. Large widgets is here.</p>'),
(4,	2,	0,	0,	'0',	'Txt-Database',	3,	1,	'2020-05-17 16:59:05',	'2017-12-13 10:42:52',	'Yt ,eltn ,jkmit ybrfrf[/',	'<p>Yt ,ltn ,jkmit ybrfr[ rjkjljrb babkmnhjd</p>'),
(5,	1,	0,	0,	'0',	'Txt-описание',	6,	1,	'2020-05-17 16:59:49',	'2017-12-13 10:44:12',	'Описание тхт датабазе',	'<p>Только наука</p>'),
(6,	2,	0,	0,	'Php-Procedure',	'PHP функции',	6,	1,	'0000-00-00 00:00:00',	'2017-12-13 12:08:50',	'Экранирование',	'<p>Php функция экранирования mysli_real_escape_string.</p>'),
(7,	3,	0,	0,	'0',	'Alert',	9,	1,	'0000-00-00 00:00:00',	'2017-12-13 12:08:50',	'Экранирование',	'<div class=\"alert alert-info\" role=\"alert\">\r\n<p>With HTML you can create your own Website.</p>\r\n<p>This tutorial teaches you everything about HTML.</p>\r\n<p>HTML is easy to learn - You will enjoy it.</p>\r\n</div>\r\n');

-- 2020-11-15 11:16:24
